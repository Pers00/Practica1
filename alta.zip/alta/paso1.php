<!doctype html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Paso 1: Alta</title>
    </head>
    <body>
        <form action="paso2.php" method="post">
            <input type="text" name="usuario"/>
            <input type="password" name="clave"/>
            <input type="password" name="claveRepetida"/>
            <input type="submit" value="next"/>
        </form>
    </body>
</html>